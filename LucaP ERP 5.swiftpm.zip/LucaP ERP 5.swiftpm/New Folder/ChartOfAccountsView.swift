import SwiftUI

struct ChartOfAccountsView: View {
    
    @Binding var selected:Int! 
    @Binding var isPresented:Bool
    
    var sortedAccounts:[Account]{
        ChartOfAccounts().accounts.sorted{$0.id < $1.id}
    }
    
    func selectedIndex(_ account:Account) -> Int!{
        sortedAccounts.firstIndex{$0.id == account.id}
    }
    
    var body: some View {
        VStack{
            ScrollView{
                ForEach(sortedAccounts){account in 
                    VStack{
                        Divider()
                        HStack{
                            Text(account.accountNumber)
                            Text(account.accountName)
                            Spacer()
                        }
                        .onTapGesture{
                            selected = selectedIndex(account)
                            isPresented = false
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ChartOfAccountsView(selected: .constant(5), isPresented: .constant(true))
}
