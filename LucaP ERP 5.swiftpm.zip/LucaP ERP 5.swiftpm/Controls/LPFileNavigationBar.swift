
import SwiftUI

// Code to make a Navigation bar for rows in a table. 

struct LPFileNavigationBar:View{
    
    @Binding var index:Int!
    var maxIndex:Int
    var minIndex:Int = 0 
    @Binding var readWrite:Bool
    
    func isInvalidIndex(){
        if index != nil {
            if index <= 0 || index > maxIndex {index = maxIndex}
        } else {
            index = maxIndex
        }
    }
    
    var body:some View{
        VStack{
            HStack{
                // Read only mode toggle
                Button{
                    readWrite.toggle()
                    
                }label:{
                    Image(systemName: "pencil")
                        .symbolVariant(readWrite ? .none : .slash)
                        .symbolRenderingMode(.hierarchical)
                        .contentTransition(.symbolEffect(.replace))
                }
                
                .fileNavButtonModifier
                .padding(.trailing,100)
                
                //First record Button
                Button{ 
                    isInvalidIndex()
                    index = 0
                }label:{
                    Image(systemName: "chevron.backward.2")
                }
                .fileNavButtonModifier
                
                
                
                //Previous record Button
                Button{
                    isInvalidIndex()
                    index = (index - 1) % maxIndex
                    
                }label:{
                    Image(systemName: "chevron.backward")
                }
                .fileNavButtonModifier
                
                // Next record Button
                Button{ 
                    isInvalidIndex()
                    index = (index + 1) % maxIndex
                }label:{
                    Image(systemName: "chevron.forward") 
                }
                .fileNavButtonModifier
                
                // Last Record Button
                Button{
                    isInvalidIndex()
                    index = maxIndex - 1
                    
                }label:{
                    Image(systemName: "chevron.forward.2")   
                }
                .fileNavButtonModifier
                
                // Add Button
                Button{
                    readWrite = true
                    index = nil
                    
                }label:{
                   Image(systemName: "document.badge.plus") 
                }
                .fileNavButtonModifier
                .padding(.leading,100)
                Spacer()
            }
            .padding()
            .background(.regularMaterial)
            
            
            
        }
        .onAppear{
            
        }
    }
    
}



struct FileNavButtonModifier:ViewModifier{
    func body(content: Content) -> some View {
        content
            .imageScale(.large)
            .padding(5)
            .frame(width: 50,height:50)
            .background(.blue, in: RoundedRectangle(cornerRadius: 8))
            .foregroundStyle(.white)
    }
}

extension View{
    var fileNavButtonModifier:some View{
        return self.modifier(ButtonModifier())
    }
}
