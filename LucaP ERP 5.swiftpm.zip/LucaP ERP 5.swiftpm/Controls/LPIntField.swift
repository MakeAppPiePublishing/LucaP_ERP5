import SwiftUI

struct LPIntField:View{
    var label:String
    @Binding var value:Int
    var isActive:Bool = true
    
    var formatter:Formatter{
        let formatter = NumberFormatter()
        formatter.numberStyle = .none
        return formatter
    }
    
    var body: some View{
        HStack{
            TextField(label,value:$value,formatter: formatter)
                .lpFieldModifier(label: label, value: formatter.string(for: value) ?? "", isActive: isActive)
                .keyboardType(.numberPad)
        }
    }
}
