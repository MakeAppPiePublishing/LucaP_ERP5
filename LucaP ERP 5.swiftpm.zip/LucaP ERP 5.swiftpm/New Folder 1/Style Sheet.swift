import SwiftUI

struct ButtonModifier:ViewModifier{
    func body(content:Content) -> some View{
        content
            .font(.body).bold()
            .imageScale(.large)
            .padding()
            .background(.blue)
            .foregroundStyle(.white)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .padding(.trailing,5)
        
    }
}

extension View{

    var buttonModifier:some View{
        self.modifier(ButtonModifier())
    }
}
