import SwiftUI
let choiceArray = [(0,"Eeny"),(1,"Meeny"),(2,"Miny"),(3,"Mo")] 
struct ContentView: View {
    
    var body: some View {
        VStack(alignment:.leading) {
            HStack{
                Image(systemName: "book.pages.fill")
                    .imageScale(.large)
                    .foregroundColor(.accentColor)
                Text("LucaP")
                Spacer()
                Text(Date(),style:.date)
            }
            LPChartOfAccountsFormView()
            Spacer()
        }
    }
}
