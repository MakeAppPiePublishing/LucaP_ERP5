import SwiftUI


struct LPTextFieldPicker:View{
    var label:String
    @Binding var contents:String
    @Binding var present:Bool
    var isActive:Bool = true
    
    var body: some View{
        HStack{
            TextField(label, text: $contents)
                .lpFieldModifier(label: label, value: contents, isActive: isActive)
            Button{
                present = true
            } label:{
                Image(systemName: "magnifyingglass.circle")
                    .imageScale(.large)
            }
        }
    }
    
}

#Preview{
    LPTextField(label:"Name",contents:.constant("Nova"),isActive:true)
}
