import SwiftUI

struct EntryTestView: View {
    // Set for test entries
    @State var journalEntries:[JournalEntry] = JournalEntries().journalEntries
    
    var body: some View {
        VStack{
            Text("General Journal - Huli Pizza Company")
                .font(.title).bold()
            List{
                ForEach(journalEntries){entry in
                    Section { 
                        ForEach(entry.fetchJournalTransactions()){transaction in
                            HStack{
                                HStack{
                                    Text(transaction.row + 1,format: .number.grouping(.never))
                                    Text(transaction.account)
                                    Text(transaction.description)
                                    Spacer()
                                }
                                .frame(width:300)
                                Spacer()
                                if transaction.creditDebit == .debit{
                                    HStack{Text(transaction.amount,format: .currency(code: "usd"))
                                        Spacer()}.frame(width:200)
                                } else {
                                    Text(" ").frame(minWidth:100)
                                    Text(transaction.amount,format: .currency(code: "usd")).frame(width:100)
                                }
                            } .padding([.leading,.trailing],10)
                        }
                    } 
                header: { 
                    HStack{
                        HStack{
                            Text(entry.docId,format: .number.grouping(.never))
                            Text(entry.date,format: .dateTime.month(.twoDigits).day(.twoDigits).year(.twoDigits))
                            Text(entry.description)
                            Spacer()
                            
                        }
                        .font(.headline)
                        .foregroundColor(.primary)
                        
                        
                    }
                } footer: {
                    HStack{
                        if !entry.balancedEntry{
                            Text("Not Balanced")
                                .padding(3)
                                .padding(.trailing,100)
                                .foregroundStyle(.white)
                                .background(.red,in:RoundedRectangle(cornerRadius: 6))
                            
                        }
                        Spacer()
                        Text(entry.totalDebits,format: .currency(code: "usd"))
                            .font(.body)
                            .frame(width: 100)
                        Text(entry.totalCredits,format: .currency(code: "usd"))
                            .font(.body)
                            .frame(width: 100)
                    }
                    .foregroundColor(entry.balancedEntry ? .primary : .orange)
                    
                }
                }
            }
        }
    }
}

#Preview {
    EntryTestView()
}
