import SwiftUI
import SwiftUI

struct LPIntPicker:View{
    var label:String
    @Binding var value:Int
    var choices:[(Int,String)]
    var isActive:Bool = true
    
    var labelValue:String{
        choices.first{$0.0 == value}?.1 ?? "Not found"
    }
    var body: some View{
        HStack{
            Picker(label, selection: $value){ 
                ForEach(choices,id:\.self.0){ choice in
                    Text(choice.1)
                        .tag(choice.0)
                }
            }
            .lpFieldModifier(label: label, value: labelValue, isActive: isActive)
        }
    }
}

let testIntPickerData = [(0,"Santa Barbara"),(2,"Chicago"),(3,"Baltimore"),(4,"Honolulu"),(5,"London")]
#Preview{
    LPIntPicker(label: "Location", value: .constant(3), choices: testIntPickerData, isActive: true)
}
