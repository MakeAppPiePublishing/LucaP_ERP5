import SwiftUI

class ChartOfAccounts{
    var accounts:[Account]
    let noAccount = Account(accountNumber: "", accountName: "", accountCategory: 0)
    init(){
        self.accounts = []
        basicAccounts() 
    }
    func account(at accountName:String) -> Account{
        accounts.first{$0.accountName == accountName} ?? noAccount
    }
    
    var sortedAccounts:[Account]{
        accounts.sorted(by: {$0.accountNumber < $1.accountNumber })
    }
    
    func lastAccount()->Account{
        return sortedAccounts.last ?? noAccount
    }
    
    func firstAccount()->Account{
        return sortedAccounts.first ?? noAccount
    }
    
    func previousAccount(before id:String)->Account{
        if let index = sortedAccounts.firstIndex(where: {$0.accountNumber == id }){
            let newIndex = index - 1
            if newIndex >= 0{
                return sortedAccounts[newIndex]
            } else {
                return sortedAccounts.last ?? noAccount
            }
        }
        return noAccount
    }
    
    
    func nextAccount(after id:String)->Account{
         if let index = sortedAccounts.firstIndex(where: {$0.accountNumber == id}){
             let newIndex = index + 1
             if newIndex != sortedAccounts.count{
                 return sortedAccounts[newIndex]
             } else {
                 return sortedAccounts.first ?? noAccount
             }
         }
        return noAccount
    }
    
    func basicAccounts(){
        //Start with common accounts
        self.accounts = [
            Account(accountNumber: "111000", accountName: "Cash on Hand", accountCategory: 1),
            Account(accountNumber: "112000", accountName: "Cash in Bank", accountCategory: 1),
            Account(accountNumber: "121000", accountName: "Accounts Recievable", accountCategory: 1),
            Account(accountNumber: "131000", accountName: "Inventory - Raw Material", accountCategory: 1),
            Account(accountNumber: "131100", accountName: "Inventory - Ingredients", accountCategory: 1),
            Account(accountNumber: "131200", accountName: "Inventory - Single Use Utensils/Packaging", accountCategory: 1),
            Account(accountNumber: "132000", accountName: "Inventory - Work in Progress", accountCategory: 1),
            Account(accountNumber: "133000", accountName: "Inventory - Assembled Parts", accountCategory: 1),
            Account(accountNumber: "134000", accountName: "Inventory - Finshed Goods", accountCategory: 1),
            Account(accountNumber: "135000", accountName: "Inventory - Purchased Finshed Goods", accountCategory: 1),
            Account(accountNumber: "161000", accountName: "Production Equipment", accountCategory: 1),
            Account(accountNumber: "162000", accountName: "Office Equipment", accountCategory: 1),
            Account(accountNumber: "163000", accountName: "Motor Vehicles", accountCategory: 1),
            Account(accountNumber: "171000", accountName: "Production Equipment", accountCategory: 1),
            Account(accountNumber: "172000", accountName: "Office Equipment", accountCategory: 1),
            Account(accountNumber: "173000", accountName: "Motor Vehicles", accountCategory: 1),
            Account(accountNumber: "173100", accountName: "Motor Vehicles - Food Trucks ", accountCategory: 1),
            Account(accountNumber: "211000", accountName: "Accounts Payable", accountCategory: 2),
            Account(accountNumber: "311000", accountName: "Common Stock", accountCategory: 3),
            Account(accountNumber: "321000", accountName: "Paid in Capital", accountCategory: 3),
            Account(accountNumber: "331000", accountName: "Retained Earnings", accountCategory: 3),
            Account(accountNumber: "411000", accountName: "Sales Revenues ", accountCategory: 4),
            Account(accountNumber: "511000", accountName: "COGS", accountCategory: 5),
            Account(accountNumber: "611000", accountName: "Payroll", accountCategory: 6),
            Account(accountNumber: "621000", accountName: "Equipment Rental",
                    accountCategory: 6),
            Account(accountNumber: "652100", accountName: "Space Rental",accountCategory: 6),
            Account(accountNumber: "631000", accountName: "Administrative Expense", accountCategory: 6),
            Account(accountNumber: "651000", accountName: "Office Supplies", accountCategory: 6),
            Account(accountNumber: "652000", accountName: "Sales and Marketing", accountCategory: 6)
            
        ]
    }
}
