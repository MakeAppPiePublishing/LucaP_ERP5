import SwiftUI

struct LPChartOfAccountsFormView:View{
    @State private var chartOfAccounts: ChartOfAccounts = ChartOfAccounts()
    @State private var accountNumber:String = ""
    @State private var accountName:String = ""
    @State private var accountCategory: Int = 0
    @State private var accountIsActive:Bool = true
    @State private var creditTotal:Float = 0.0
    @State private var debitTotal:Float = 0.0
    @State private var readWriteForm:Bool = true
    @State private var showAccountSheet:Bool = false
    @State private var selectedAccount:Account = Account(accountNumber: "", accountName: "", accountCategory: 0)
    @State private var index:Int! = nil
    @State private var newEntry = true
    
    //changes label on button for states of okay,Add,and, change
    var okayButtonLabel:String{
        if readWriteForm{
            if index == nil {
                return "Add"
            } else {
                return "Change"
            }
        } else {
            return "Okay"
        }
    }
    
    func updateUI(with account:Account){
        accountNumber = account.accountNumber
        accountName = account.accountName
        accountCategory = account.accountCategory
        accountIsActive = account.isActive
        creditTotal = account.creditTotal
        debitTotal =  account.debitTotal
        newEntry = accountNumber == ""
    }
    
    func updateUI(index:Int!){
        if let index = index{
            selectedAccount = sortedAccounts[index]
            updateUI(with: selectedAccount)
        } else{
            accountNumber = ""
            accountName = ""
            accountCategory = 0
            accountIsActive = true
            creditTotal = 0
            debitTotal =  0
        }
    }
    
    func updateModel(){
        
    }
    
    func addModel(){
        
        
    }
    
    var sortedAccounts:[Account]{
        return chartOfAccounts.accounts.sorted(by:{$0.id < $1.id})
    }
    
    /// identifiy the current id
    var idValue:String{
        if let index = self.index{
            return sortedAccounts[index].id
        } 
        return ""
    }
    
    
    var body: some View{
        VStack(alignment:.leading){
            LPFileNavigationBar(
                index: $index,
                maxIndex: chartOfAccounts.accounts.count,
                readWrite: $readWriteForm
            )
            HStack(alignment:.top){
                VStack(alignment:.leading){
                    if index == nil{
                        LPTextFieldPicker(label: "Account#", contents:.constant(idValue) ,present:$showAccountSheet, isActive: readWriteForm)
                    } else {
                        LPTextFieldPicker(label: "Account#", contents: .constant(idValue),present:$showAccountSheet, isActive: false)
                    }
                    LPTextField(label: "Account Name", contents: $accountName, isActive: readWriteForm)
                    LPIntPicker(label: "Category", value: $accountCategory, choices: AccountCategories().accountCategories.map{($0.id,$0.name)}, isActive: readWriteForm)
                    LPCheckBox(label: "Active", value: $accountIsActive, isActive: readWriteForm)
                    Spacer()
                    
                }
                VStack(alignment:.leading){
                    LPCurrencyField(label: "Total Debits", value: $debitTotal, isActive: false)
                    LPCurrencyField(label: "Total Credits", value: $creditTotal, isActive: false)
                    Spacer()
                }
            }
            .sheet(isPresented: $showAccountSheet) { 
                updateUI(with: selectedAccount)
            } content:{
                ChartOfAccountsView(selected: $index, isPresented: $showAccountSheet)
            }
            Spacer()
            // Footer -- info bar. 
            HStack{
              if index == nil{
                  Text("Add Mode")
              } else {
                  if index == sortedAccounts.count - 1{
                      Text("Last Record")
                  }
                  if index == 0 {
                      Text("First Record")
                  }
              }
              Spacer()
                Button(okayButtonLabel){
                    if readWriteForm{
                        if index == nil{
                            addModel()
                        } else {
                            updateModel()
                        }
                    } else {
                        //dismissal code here
                    }
                }
                .frame(minWidth:125)
                .buttonModifier
                
                Button("Cancel"){
                    //dismissal code here
                }
                .frame(minWidth:125)
                .buttonModifier
                
            }
            .padding()
            .background(.thinMaterial)

        }
        .onChange(of: index) { oldValue, newValue in
            updateUI(index: newValue)
        }
    }
}

#Preview{
    LPChartOfAccountsFormView()
}
