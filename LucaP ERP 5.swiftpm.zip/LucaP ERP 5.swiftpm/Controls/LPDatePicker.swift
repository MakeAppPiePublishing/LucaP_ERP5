import SwiftUI

struct LPDatePicker:View{
    var label:String
    @Binding var value:Date
    var isActive:Bool = true
    
    var formatter:Formatter{
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        return formatter
    }
    
    var body: some View{
        HStack{
            DatePicker("", selection: $value,displayedComponents: .date)
                .lpFieldModifier(label: label, value: formatter.string(for: value) ?? "", isActive: isActive)
                .keyboardType(.decimalPad)
        }
    }
}

#Preview{
    LPDatePicker(label: "Posting Date", value: .constant(Date(timeIntervalSinceNow: 1234567)), isActive: true)
}
